import React from 'react'

const OtherWeather = () => {
  return (
    <div className='h-full flex flex-col items-center justify-center bg-gray-300'>
        Other Weather Conditions</div>
  )
}

export default OtherWeather